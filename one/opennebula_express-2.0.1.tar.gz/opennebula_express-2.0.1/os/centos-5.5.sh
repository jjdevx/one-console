# -------------------------------------------------------------------------- #
# Copyright 2010, C12G Labs S.L.                                             #
#                                                                            #
# Licensed under the C12G Commercial Open-source License (the                #
# "License"); you may not use this file except in compliance                 #
# with the License. You may obtain a copy of the License as part             #
# of the software distribution.                                              #
#                                                                            #
# Unless agreed to in writing, software distributed under the                #
# License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES             #
# OR CONDITIONS OF ANY KIND, either express or implied. See the              #
# License for the specific language governing permissions and                #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

OS='CentOS 5.5'
FRONTEND_DEPS="nfs-kernel-server openssh-server ruby rubygems gcc \
rubygems ruby-devel libxslt-devel glibc-headers"
PATH=/sbin:/usr/sbin:$PATH
NODE_DEPS="sudo xen"

if [ "$ARCH" = 'x86_64' ];then
	BINARY=http://dev.opennebula.org/attachments/download/222/opennebula-2.0-1.x86_64.rpm
else
	BINARY=http://dev.opennebula.org/attachments/download/223/opennebula-2.0-1.i386.rpm
fi


function update_package_manager {
	echo 0 > /dev/null
}

function install_packages {
	yum -y --nogpgcheck install $*
}

function local_install_package {
	file_basename=$(basename $1)
	yum -y --nogpgcheck localinstall $file_basename
}

function system_create_user {
	user_name=$1
	home_dir=$2
	uid=$3
	gid=$4
	
	/usr/sbin/groupadd -g $gid $user_name
	/usr/sbin/useradd -m -d $home_dir -s /bin/bash -u $uid -g $gid $user_name
}

function install_dependencies {
	install_binary http://download.fedora.redhat.com/pub/epel/5/i386/epel-release-5-3.noarch.rpm
	if [ "$ARCH" = "x86_64" ]; then
		install_binary http://centos.karan.org/el5/extras/testing/x86_64/RPMS/xmlrpc-c-1.06.18-1.el5.kb.x86_64.rpm
		install_binary http://centos.karan.org/el5/extras/testing/x86_64/RPMS/xmlrpc-c-devel-1.06.18-1.el5.kb.x86_64.rpm
	else
		install_binary http://centos.karan.org/el5/extras/testing/i386/RPMS/xmlrpc-c-1.06.18-1.el5.kb.i386.rpm
		install_binary http://centos.karan.org/el5/extras/testing/i386/RPMS/xmlrpc-c-devel-1.06.18-1.el5.kb.i386.rpm
	fi
	install_packages $*
}

function start_daemons {
	service nfs start
	service sshd start
}

function configure_grub_xen {
	cp /boot/grub/menu.lst{,.bk_one_express}
	sed -i '/^default/s/^/#/' /boot/grub/menu.lst
}
