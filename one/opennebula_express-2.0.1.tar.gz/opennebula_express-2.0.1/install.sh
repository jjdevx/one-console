#!/bin/bash

# -------------------------------------------------------------------------- #
# Copyright 2010, C12G Labs S.L.                                             #
#                                                                            #
# Licensed under the C12G Commercial Open-source License (the                #
# "License"); you may not use this file except in compliance                 #
# with the License. You may obtain a copy of the License as part             #
# of the software distribution.                                              #
#                                                                            #
# Unless agreed to in writing, software distributed under the                #
# License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES             #
# OR CONDITIONS OF ANY KIND, either express or implied. See the              #
# License for the specific language governing permissions and                #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

# CONFIGURATION
ONE_LOCATION=/srv/cloud/one
ONE_HOME=/home/oneadmin
ONE_ETC=/etc/one
ONE_VAR=/var/lib/one
USERID=9000
GROUPID=9000
LOG=install.log
NODE_INSTALL_TEMPLATE=templates/node-template.sh
NODE_INSTALL=node-install.sh
ARCH=$(uname -m)

source lib/helper.sh

function usage {
	echo "Usage: $0 [-n] [-h]"
	echo "-n: Does not install anything in the frontend."
	echo "    It will only generate the node installer script: $NODE_INSTALL."
	echo "-h: Prints this help."
	exit
}

function select_deployment {
	msg "Select deployment type (press '0' to exit):"
	msg "1) Ubuntu 10.04 - KVM - NFS"
	msg "2) Ubuntu 10.04 - KVM - SSH"
	msg "3) CentOS 5.5 - Xen - NFS"
	msg "4) CentOS 5.5 - Xen - SSH"
	read DEPLOYMENT
	
	case $DEPLOYMENT in
		1) 
			HYPERVISOR='KVM'
			TM='NFS'
			OS_FILE=ubuntu-10.04.sh
			source os/$OS_FILE
			;;
		2) 
			HYPERVISOR='KVM'
			TM='SSH'
			OS_FILE=ubuntu-10.04.sh
			source os/$OS_FILE
			;;
		3) 
			HYPERVISOR='XEN'
			TM='NFS'
			OS_FILE=centos-5.5.sh
			source os/$OS_FILE
			;;
		4) 
			HYPERVISOR='XEN'
			TM='SSH'
			OS_FILE=centos-5.5.sh
			source os/$OS_FILE
			;;
		*)
			exit 1
			;;
	esac
	
	msg ""	
}

function ask_nfs_configuration {
	msg "You have selected an NFS deployment. Do you want automatic configuration"
	msg "of NFS in the frontend and nodes? If you select this option you will be"
	msg "asked for the IP of the frontend to which the nodes will have acces to,"
	msg "and the network to which they belong to (for example: '192.168.1.0/24')."
	echo -n "(y/n) " >&6
	read OPT
	case $OPT in 
		y*|Y*)
			OPT='yes'
			;;
		*)	OPT='no'
			;;
	esac
	msg ""
	if [ "$OPT" = 'yes' ]; then
		msg "Input the IP of the frontend:"
		read IP
		DEFAULT_NETWORK=$(echo $IP|cut -d. -f1-3).0/24
		msg "Input the network (press enter for '$DEFAULT_NETWORK'):"
		read NETWORK
		[ -z "$NETWORK" ] && NETWORK=$DEFAULT_NETWORK
	fi
	msg ""
}

function configure_files {
	# Configure oned.conf
	ONED_CONF=conf/oned.conf.$(echo $HYPERVISOR|tr 'A-Z' 'a-z')-$(echo $TM|tr 'A-Z' 'a-z')
	cp $ONED_CONF $ONE_ETC/oned.conf
	
	# Environment variables
	cat >> $ONE_HOME/.bashrc <<EOT
source $ONE_HOME/.one-env
EOT
	cat >> $ONE_HOME/.one-env <<EOT
#export ONE_LOCATION=$ONE_LOCATION
export ONE_AUTH=\$HOME/.one-auth
export ONE_XMLRPC=http://localhost:2633/RPC2
#export PATH=$ONE_LOCATION/bin:$PATH
EOT
}

function install_gems {
	gem install --no-ri --no-rdoc nokogiri
}

function one_auth {
	echo "oneadmin:oneadmin" > $ONE_HOME/.one-auth
}

function start_one {
	su - oneadmin -c "source $ONE_HOME/.one-env; one start"
}

function create_ssh_keys {
	sudo -u oneadmin ssh-keygen -q -t dsa -N "" -f $ONE_HOME/.ssh/id_dsa < /dev/null
	sudo -u oneadmin touch $ONE_HOME/.ssh/config
	cat > $ONE_HOME/.ssh/config <<EOT
UserKnownHostsFile /dev/null
Host *
    StrictHostKeyChecking no
EOT
	sudo -u oneadmin cp $ONE_HOME/.ssh/id_dsa.pub $ONE_HOME/.ssh/authorized_keys
}

function  configure_nfs_frontend {
	if [ "$OS" = "CentOS 5.5" ]; then
		if [ "$TM" = 'NFS' ]; then
			/sbin/service nfs start
		fi
	fi
	echo "$ONE_VAR $NETWORK(rw,async,no_subtree_check)" >> /etc/exports
	exportfs -a
}

function prepare_node_install {
	cp $NODE_INSTALL_TEMPLATE $NODE_INSTALL
	substitute ONE_LOCATION $ONE_LOCATION $NODE_INSTALL
	substitute ONE_HOME $ONE_HOME $NODE_INSTALL
	substitute ONE_VAR $ONE_VAR $NODE_INSTALL
	substitute USERID $USERID $NODE_INSTALL
	substitute GROUPID $GROUPID $NODE_INSTALL
	substitute LOG $LOG $NODE_INSTALL
	substitute NODE_DEPS "$NODE_DEPS" $NODE_INSTALL
	substitute HYPERVISOR "$HYPERVISOR" $NODE_INSTALL
	substitute TM "$TM" $NODE_INSTALL
	substitute NETWORK "$NETWORK" $NODE_INSTALL
	substitute IP "$IP" $NODE_INSTALL

	include_file helper lib/helper.sh $NODE_INSTALL
	include_file os os/$OS_FILE $NODE_INSTALL
	include_file pubkey $ONE_HOME/.ssh/id_dsa.pub $NODE_INSTALL
	
	msg "Generated install script for the nodes: $NODE_INSTALL."
	msg "Execute $NODE_INSTALL in your nodes to configure it as an OpenNebula"
	msg "worker node."
	msg ""
	configure_bridge
}

function review_configuration {
	msg "Review your configuration:"
	msg ""
	if [ -n "$ONLY_NODE" ]; then
		msg "- Only node installation"
	fi
	msg "- OS: $OS"
	msg "- Hypervisor: $HYPERVISOR"
	msg "- Transfer Maneger: $TM"
	msg "- NFS configuration"
	if [ -n "$NETWORK" -a -n "$IP" ]; then
		msg "\tIP: $IP"
		msg "\tNetwork: $NETWORK"
	else
		msg "\tno NFS configuration"
	fi
	msg ""
	echo -n "Proceed? (y/n) " >&6
	read PROCEED
	case $PROCEED in 
		n*|N*)
			msg "Canceled by user"
			exit
			;;
	esac	
}

while getopts "nh" opt; do
  case $opt in
    n)
    	ONLY_NODE=true
    	;;
	*)
		usage
		;;
  esac
done

# MAIN
stdin_stdout_to_log
select_deployment
if [ "$TM" = "NFS" ]; then
	ask_nfs_configuration
fi
review_configuration
if [ -z "$ONLY_NODE" ]; then
	capture_spin
	start_spin
	run "install_dependencies $FRONTEND_DEPS" '- Installing frontend dependencies'
	run "install_gems $FRONTEND_GEMS" '- Installing gems'
	run create_user_oneadmin '- Creating user oneadmin'
	run "install_binary $BINARY" '- Downloading and installing binary package'
	run configure_files '- Processing configuration files'
	run one_auth '- Writing ONE_AUTH file'
	run start_one '- Starting OpenNebula'
	run create_ssh_keys '- Creating SSH Keys'
	if [ "$TM" = 'NFS' ]; then
		run configure_nfs_frontend '- Configure NFS'
	fi
	stop_spin
	msg "Success!"
fi

prepare_node_install


