#!/bin/bash

# -------------------------------------------------------------------------- #
# Copyright 2010, C12G Labs S.L.                                             #
#                                                                            #
# Licensed under the C12G Commercial Open-source License (the                #
# "License"); you may not use this file except in compliance                 #
# with the License. You may obtain a copy of the License as part             #
# of the software distribution.                                              #
#                                                                            #
# Unless agreed to in writing, software distributed under the                #
# License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES             #
# OR CONDITIONS OF ANY KIND, either express or implied. See the              #
# License for the specific language governing permissions and                #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

ONE_LOCATION=/srv/cloud/one
ONE_HOME=/home/oneadmin
ONE_VAR=/var/lib/one
USERID=9000
GROUPID=9000
LOG=install.log
NODE_DEPS="nfs-common openssh-server kvm libvirt-bin ruby"
HYPERVISOR=KVM
TM=NFS
NETWORK=192.168.2.0/24
IP=192.168.2.1


# -------------------------------------------------------------------------- #
# Copyright 2010, C12G Labs S.L.                                             #
#                                                                            #
# Licensed under the C12G Commercial Open-source License (the                #
# "License"); you may not use this file except in compliance                 #
# with the License. You may obtain a copy of the License as part             #
# of the software distribution.                                              #
#                                                                            #
# Unless agreed to in writing, software distributed under the                #
# License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES             #
# OR CONDITIONS OF ANY KIND, either express or implied. See the              #
# License for the specific language governing permissions and                #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

# COLORS
txtred='\e[0;31m' # Red
txtgrn='\e[0;32m' # Green
txtrst='\e[0m'    # Text Reset

function capture_spin {
	trap "stop_spin" SIGINT SIGTERM
}

function stdin_stdout_to_log {
	exec 6>&1
	exec &> $LOG
}

function start_spin {
	(while true
	do
		echo -en '/\010' >&6; sleep .1
		echo -en '-\010' >&6; sleep .1
		echo -en '\\\010' >&6; sleep .1
		echo -en '|\010' >&6; sleep .1
	done) &
	SPIN_PID=$!
}

function stop_spin {
	kill $SPIN_PID
	echo ' ' >&6
}

function msg {
	echo -e $* >&6
}

function msg_log {
	msg $*
	echo $*
}

function msg_banner {
	msg $*
	echo -e "=================================="
	echo $*
	echo -e "==================================\n"	
}

function msg_log_green {
	echo -en "${txtgrn}" >&6
	msg $*
	echo -en "${txtrst}" >&6
	echo $*
}

function run {
	msg_banner $2
	$1
	if [ "$?" != "0" ]; then
		echo -e "${txtred}ERROR: Please check $LOG${txtrst}" >&6
		stop_spin
		exit 1
	fi
}

function run_no_stop {
	msg_banner $2
	$1
}

function manual_install_banner {
	msg ""
	msg "The automatic installation finished succesfully! You have to make a \
few manual changes depending on your configuration. You can find the \
following instructions in $LOG."
	msg ""
}

function include_file {
	KEY=$1
	FILE=$2
	OUTFILE=$3
	sed -i -e "/#include_$KEY#/ r $2" -e "/#include_$KEY#/d" $OUTFILE 
}

function substitute {
    KEY=$1
    VALUE=$2
    OUTFILE=$3
    sed -i -e "s%#$1#%$2%g" $OUTFILE
}

function create_user_oneadmin {
	mkdir -p $(dirname $ONE_HOME)
	system_create_user oneadmin $ONE_HOME $USERID $GROUPID 
}

function install_binary {
	wget $1
	local_install_package $1
	rm -f $(basename $1)
}

function add_user_group {
	gpasswd -a $1 $2
}

function configure_bridge {
	msg_banner "- Configure bridge manually"
	msg ""
	msg_log "Don't forget to configure your bridges in your nodes, so you can"
	msg_log "pass them to OpenNebula. To do so use:"
	msg ""
	msg_log "'brctl addbr br0' # creates bridge br0"
	msg_log "'brctl addif br0 eth0' # add interface eth0 to bridge br0"
	msg ""
	msg_log "and configure the IP of your bridge interface. "
}

# -------------------------------------------------------------------------- #
# Copyright 2010, C12G Labs S.L.                                             #
#                                                                            #
# Licensed under the C12G Commercial Open-source License (the                #
# "License"); you may not use this file except in compliance                 #
# with the License. You may obtain a copy of the License as part             #
# of the software distribution.                                              #
#                                                                            #
# Unless agreed to in writing, software distributed under the                #
# License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES             #
# OR CONDITIONS OF ANY KIND, either express or implied. See the              #
# License for the specific language governing permissions and                #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

OS='Ubuntu 10.04'
FRONTEND_DEPS="nfs-kernel-server openssh-server ruby rubygems \
ruby-dev libcurl3 libsqlite3-ruby libsqlite3-ruby1.8 libxmlrpc-c3 \
libxmlrpc-core-c3 libxml2-dev libxslt1-dev"

if [ "$TM" = "NFS" ];then
	NODE_DEPS="nfs-common openssh-server kvm libvirt-bin ruby"
elif [ "$TM" = "SSH" ];then
	NODE_DEPS="openssh-server kvm libvirt-bin ruby"
fi

if [ "$ARCH" = 'x86_64' ];then
	BINARY=http://dev.opennebula.org/attachments/download/220/opennebula_2.0-1_amd64.deb
else
	BINARY=http://dev.opennebula.org/attachments/download/221/opennebula_2.0-1_i386.deb
fi


function install_dependencies {
	update_package_manager
	install_packages $*
}

function update_package_manager {
	apt-get update
}

function install_packages {
	apt-get -y install $*
}

function local_install_package {
	file_basename=$(basename $1)
	dpkg -i $file_basename
	apt-get -fy install
}

function system_create_user {
	user_name=$1
	home_dir=$2
	uid=$3
	gid=$4
	
	groupadd -g $gid $user_name
	useradd -m -d $home_dir -s /bin/bash -u $uid -g $gid $user_name
}

stdin_stdout_to_log
capture_spin

function configure_pubkey {
	mkdir -m 700 -p $ONE_HOME/.ssh
	cat > $ONE_HOME/.ssh/authorized_keys <<EOT
ssh-dss AAAAB3NzaC1kc3MAAACBAMPb0FLjE/KALtVrbjwKhWPkoXxHepZVxUbzepCMwu1ivk+U5/EJPux6qf7mYeFXWiUWRK+haex7QLq/Gj+SuD6gA+qA+fY3zx3fSsKdBQgB8Ks5QdWccGTpzOd0DfdU/Kos2o4FWE0rvEhvSyeFum9wqzs0XuW7h33BFFIjUQF5AAAAFQCnXECQI+z1lSsc1sb2nqaS0c6aHQAAAIEAqlf0zEpCSmxEyKAmFnY1sf1p4F6A9/l+ECGV7s1pZ348gagtzDKAU2MBiEZgxWnJ4TTI+RaewM6HteUP13+wx7yIbv64jzhkuUCnWuwdVC4ZYAhgzRngiB+Cdee9fSBoZVN1AOTSOJpdKsx1SPYMZ8uy3qZ+ESCb0xdNxALog1MAAACAbO/4Gj39oNYTIXD2t6oQLGdYTMH+173eXdXUpQPdLTCAMyO4suhHoZkC355YgcTHUtLHT+/0m1BIX8WuP1lRvIofSvy7rapr/dqs8JvQXPrd3Nw5zmbMMxY8FFaiiyp/2yHhh+INd4ey60WClzOkmpSxzn2XOteovmoD2n9LuSk= oneadmin@anuchit-ch
EOT
	chmod 600 $ONE_LHOME/.ssh/authorized_keys
	chown -R oneadmin:oneadmin $ONE_HOME/.ssh
}

function configure_sudo_xen {
	echo "oneadmin	ALL=(ALL) NOPASSWD: /usr/sbin/xm, /usr/sbin/xentop" \
		>> /etc/sudoers
}

function configure_nfs {
	mkdir -p $ONE_VAR
	echo "$IP:$ONE_VAR $ONE_VAR nfs \
soft,intr,rsize=32768,wsize=32768,rw 0 0" >> /etc/fstab
	mount -a	
}

#automatic installation
start_spin
run "install_dependencies $NODE_DEPS" '- Installing node dependencies'
if [ "$TM" = "NFS" -a -n "$NETWORK" -a -n "$IP" ]; then
	run configure_nfs "- Configuring NFS"
fi
run create_user_oneadmin '- Creating user oneadmin'
if [ "$TM" = "SSH" ]; then
	run configure_pubkey '- Adding public key'
fi

if [ "$HYPERVISOR" = "XEN" ]; then
	run configure_sudo_xen "- Configuring /etc/sudoers"
	run configure_grub_xen "- Configuring grub"
elif [ "$HYPERVISOR" = "KVM" ]; then
	run "add_user_group oneadmin libvirtd" "- Adding user oneadmin to group libvirtd"
fi
stop_spin
configure_bridge
if [ "$HYPERVISOR" = "XEN" ]; then
	msg ""
	msg "To enable Xen you must to manually reboot your node server."
fi
msg "Success!"