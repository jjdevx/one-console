# -------------------------------------------------------------------------- #
# Copyright 2010, C12G Labs S.L.                                             #
#                                                                            #
# Licensed under the C12G Commercial Open-source License (the                #
# "License"); you may not use this file except in compliance                 #
# with the License. You may obtain a copy of the License as part             #
# of the software distribution.                                              #
#                                                                            #
# Unless agreed to in writing, software distributed under the                #
# License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES             #
# OR CONDITIONS OF ANY KIND, either express or implied. See the              #
# License for the specific language governing permissions and                #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

# COLORS
txtred='\e[0;31m' # Red
txtgrn='\e[0;32m' # Green
txtrst='\e[0m'    # Text Reset

function capture_spin {
	trap "stop_spin" SIGINT SIGTERM
}

function stdin_stdout_to_log {
	exec 6>&1
	exec &> $LOG
}

function start_spin {
	(while true
	do
		echo -en '/\010' >&6; sleep .1
		echo -en '-\010' >&6; sleep .1
		echo -en '\\\010' >&6; sleep .1
		echo -en '|\010' >&6; sleep .1
	done) &
	SPIN_PID=$!
}

function stop_spin {
	kill $SPIN_PID
	echo ' ' >&6
}

function msg {
	echo -e $* >&6
}

function msg_log {
	msg $*
	echo $*
}

function msg_banner {
	msg $*
	echo -e "=================================="
	echo $*
	echo -e "==================================\n"	
}

function msg_log_green {
	echo -en "${txtgrn}" >&6
	msg $*
	echo -en "${txtrst}" >&6
	echo $*
}

function run {
	msg_banner $2
	$1
	if [ "$?" != "0" ]; then
		echo -e "${txtred}ERROR: Please check $LOG${txtrst}" >&6
		stop_spin
		exit 1
	fi
}

function run_no_stop {
	msg_banner $2
	$1
}

function manual_install_banner {
	msg ""
	msg "The automatic installation finished succesfully! You have to make a \
few manual changes depending on your configuration. You can find the \
following instructions in $LOG."
	msg ""
}

function include_file {
	KEY=$1
	FILE=$2
	OUTFILE=$3
	sed -i -e "/#include_$KEY#/ r $2" -e "/#include_$KEY#/d" $OUTFILE 
}

function substitute {
    KEY=$1
    VALUE=$2
    OUTFILE=$3
    sed -i -e "s%#$1#%$2%g" $OUTFILE
}

function create_user_oneadmin {
	mkdir -p $(dirname $ONE_HOME)
	system_create_user oneadmin $ONE_HOME $USERID $GROUPID 
}

function install_binary {
	wget $1
	local_install_package $1
	rm -f $(basename $1)
}

function add_user_group {
	gpasswd -a $1 $2
}

function configure_bridge {
	msg_banner "- Configure bridge manually"
	msg ""
	msg_log "Don't forget to configure your bridges in your nodes, so you can"
	msg_log "pass them to OpenNebula. To do so use:"
	msg ""
	msg_log "'brctl addbr br0' # creates bridge br0"
	msg_log "'brctl addif br0 eth0' # add interface eth0 to bridge br0"
	msg ""
	msg_log "and configure the IP of your bridge interface. "
}

