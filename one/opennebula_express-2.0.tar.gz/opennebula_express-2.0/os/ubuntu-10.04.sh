# -------------------------------------------------------------------------- #
# Copyright 2010, C12G Labs S.L.                                             #
#                                                                            #
# Licensed under the C12G Commercial Open-source License (the                #
# "License"); you may not use this file except in compliance                 #
# with the License. You may obtain a copy of the License as part             #
# of the software distribution.                                              #
#                                                                            #
# Unless agreed to in writing, software distributed under the                #
# License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES             #
# OR CONDITIONS OF ANY KIND, either express or implied. See the              #
# License for the specific language governing permissions and                #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

OS='Ubuntu 10.04'
FRONTEND_DEPS="nfs-kernel-server openssh-server ruby rubygems \
ruby-dev libcurl3 libsqlite3-ruby libsqlite3-ruby1.8 libxmlrpc-c3 \
libxmlrpc-core-c3 libxml2-dev libxslt1-dev"

if [ "$TM" = "NFS" ];then
	NODE_DEPS="nfs-common openssh-server kvm libvirt-bin ruby"
elif [ "$TM" = "SSH" ];then
	NODE_DEPS="openssh-server kvm libvirt-bin ruby"
fi

if [ "$ARCH" = 'x86_64' ];then
	BINARY=http://dev.opennebula.org/attachments/download/220/opennebula_2.0-1_amd64.deb
else
	BINARY=http://dev.opennebula.org/attachments/download/221/opennebula_2.0-1_i386.deb
fi


function install_dependencies {
	update_package_manager
	install_packages $*
}

function update_package_manager {
	apt-get update
}

function install_packages {
	apt-get -y install $*
}

function local_install_package {
	file_basename=$(basename $1)
	dpkg -i $file_basename
	apt-get -fy install
}

function system_create_user {
	user_name=$1
	home_dir=$2
	uid=$3
	gid=$4
	
	groupadd -g $gid $user_name
	useradd -m -d $home_dir -s /bin/bash -u $uid -g $gid $user_name
}
