#!/bin/bash

# -------------------------------------------------------------------------- #
# Copyright 2010, C12G Labs S.L.                                             #
#                                                                            #
# Licensed under the C12G Commercial Open-source License (the                #
# "License"); you may not use this file except in compliance                 #
# with the License. You may obtain a copy of the License as part             #
# of the software distribution.                                              #
#                                                                            #
# Unless agreed to in writing, software distributed under the                #
# License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES             #
# OR CONDITIONS OF ANY KIND, either express or implied. See the              #
# License for the specific language governing permissions and                #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #

ONE_LOCATION=#ONE_LOCATION#
ONE_HOME=#ONE_HOME#
ONE_VAR=#ONE_VAR#
USERID=#USERID#
GROUPID=#GROUPID#
LOG=#LOG#
NODE_DEPS="#NODE_DEPS#"
HYPERVISOR=#HYPERVISOR#
TM=#TM#
NETWORK=#NETWORK#
IP=#IP#


#include_helper#
#include_os#

stdin_stdout_to_log
capture_spin

function configure_pubkey {
	mkdir -m 700 -p $ONE_HOME/.ssh
	cat > $ONE_HOME/.ssh/authorized_keys <<EOT
#include_pubkey#	
EOT
	chmod 600 $ONE_LHOME/.ssh/authorized_keys
	chown -R oneadmin:oneadmin $ONE_HOME/.ssh
}

function configure_sudo_xen {
	echo "oneadmin	ALL=(ALL) NOPASSWD: /usr/sbin/xm, /usr/sbin/xentop" \
		>> /etc/sudoers
}

function configure_nfs {
	mkdir -p $ONE_VAR
	echo "$IP:$ONE_VAR $ONE_VAR nfs \
soft,intr,rsize=32768,wsize=32768,rw 0 0" >> /etc/fstab
	mount -a	
}

#automatic installation
start_spin
run "install_dependencies $NODE_DEPS" '- Installing node dependencies'
if [ "$TM" = "NFS" -a -n "$NETWORK" -a -n "$IP" ]; then
	run configure_nfs "- Configuring NFS"
fi
run create_user_oneadmin '- Creating user oneadmin'
if [ "$TM" = "SSH" ]; then
	run configure_pubkey '- Adding public key'
fi

if [ "$HYPERVISOR" = "XEN" ]; then
	run configure_sudo_xen "- Configuring /etc/sudoers"
	run configure_grub_xen "- Configuring grub"
elif [ "$HYPERVISOR" = "KVM" ]; then
	run "add_user_group oneadmin libvirtd" "- Adding user oneadmin to group libvirtd"
fi
stop_spin
configure_bridge
if [ "$HYPERVISOR" = "XEN" ]; then
	msg ""
	msg "To enable Xen you must to manually reboot your node server."
fi
msg "Success!"